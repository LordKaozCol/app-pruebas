package com.learneasyapp.app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.learneasyapp.app.database.SQLite;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.new_account).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Register.class);
                startActivity(intent);
            }
        });

        findViewById(R.id.login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        SQLite sqlite = new SQLite(getApplicationContext());

        Toast.makeText(getApplicationContext(), "USUARIO REGISTRADO", Toast.LENGTH_LONG).show();
        ArrayList<HashMap> usuarios = sqlite.getAllUsuarios();
        for (HashMap map : usuarios) {
            Log.i("register", "nombre: " + map.get("nombre").toString());
            Log.i("register", "contrasena: " + map.get("contrasena").toString());
        }

    }

    public void login() {
        String correo = ((EditText) findViewById(R.id.email)).getText().toString();
        String contrasena = ((EditText) findViewById(R.id.password)).getText().toString();

        SQLite sqLite = new SQLite(getApplicationContext());
        HashMap usuario = sqLite.findForLogin(correo, contrasena);
        if (usuario != null) {
            Toast.makeText(getApplicationContext(), "Bienvenido " + usuario.get("nombre"), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getApplicationContext(), "Credenciales invalidas", Toast.LENGTH_LONG).show();
        }
    }
}
