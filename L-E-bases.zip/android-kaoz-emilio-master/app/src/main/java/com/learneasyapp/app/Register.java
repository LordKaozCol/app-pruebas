package com.learneasyapp.app;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.learneasyapp.app.database.SQLite;

import java.util.ArrayList;
import java.util.HashMap;

public class Register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        findViewById(R.id.register).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register();
            }
        });
    }

    public void register(){
        String nombre = ((EditText)findViewById(R.id.nombre)).getText().toString();
        String correo = ((EditText)findViewById(R.id.correo)).getText().toString();
        String cedula = ((EditText)findViewById(R.id.cedula)).getText().toString();
        String contrasena = ((EditText)findViewById(R.id.contrasena)).getText().toString();

        SQLite sqlite = new SQLite(getApplicationContext());
        Log.i("", "nombre: "+nombre+", correo: "+correo+", cedula: "+cedula+", contrasena: "+contrasena);
        if(sqlite.insertUsuario(nombre, correo, contrasena, cedula)){
            Toast.makeText(getApplicationContext(), "USUARIO REGISTRADO", Toast.LENGTH_LONG).show();
            ArrayList<HashMap> usuarios = sqlite.getAllUsuarios();
            for(HashMap map : usuarios){
                Log.i("register", "nombre: "+map.get("nombre").toString());
                Log.i("register", "contrasena: "+map.get("contrasena").toString());
            }
        }


    }
}
