package com.learneasyapp.app.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.DatabaseUtils;
import java.util.ArrayList;
import java.util.HashMap;

public class SQLite extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "app.db";

    private HashMap hp;

    public SQLite(Context context) {
        super(context, DATABASE_NAME, null, 3);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Crea la tabla
        db.execSQL("CREATE TABLE usuarios (id INTEGER PRIMARY KEY, nombre TEXT, email TEXT UNIQUE, contrasena TEXT, cedula INTEGER UNIQUE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // borramos todo para actualizar
        db.execSQL("DROP TABLE IF EXISTS usuarios;");
        onCreate(db);
    }

    /**
     * Inserta un nuevo usuario
     * @param nombre
     * @param email
     * @param contrasena
     * @param cedula
     * @return true si lo inserta, false si falla
     */
    public boolean insertUsuario(String nombre, String email, String contrasena, String cedula) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id", java.util.Calendar.getInstance().getTimeInMillis());
        contentValues.put("nombre", nombre);
        contentValues.put("email", email);
        contentValues.put("contrasena", contrasena);
        contentValues.put("cedula", cedula);

        try {
            db.insertOrThrow("usuarios", null, contentValues);
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }

    }

    /**
     * Obtiene el numero de registros de una tabla
     * @param table
     * @return
     */
    public int numberOfRows(String table) {
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, table);
        return numRows;
    }

    /**
     * Actualiza un usuario existente
     * @param id
     * @param nombre
     * @param email
     * @param contrasena
     * @param cedula
     * @return
     */
    public boolean updateUsuario(long id , String nombre, String email, String contrasena, String cedula) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("id", id);
        contentValues.put("nombre", nombre);
        contentValues.put("email", email);
        contentValues.put("contrasena", contrasena);
        contentValues.put("cedula", cedula);
        try {
            db.update("usuarios", contentValues, "id = ? ", new String[]{String.valueOf(id)});
        } catch (Exception ex) {

        }
        return true;
    }

    /**
     * elimina un usuario
     * @param id
     * @return
     */
    public Integer deleteUsuario(Long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("usuarios",
                "id = ? ",
                new String[]{Long.toString(id)});
    }

    public HashMap getUsuario(Object id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from usuarios where id = ? ", new String[]{String.valueOf(id)});
        res.moveToFirst();
        HashMap usuario = new HashMap();
        while (res.isAfterLast() == false) {
            //array_list.add(res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)));
            usuario.put("id", res.getInt(res.getColumnIndex("id")));
            usuario.put("nombre", res.getString(res.getColumnIndex("nombre")));
            usuario.put("cedula", res.getString(res.getColumnIndex("cedula")));
            usuario.put("email", res.getString(res.getColumnIndex("email")));


            res.moveToNext();
        }
        return usuario;
    }

    public ArrayList<HashMap> getAllUsuarios(String filtro) {
        filtro = "%" + filtro.replace(" ", "%") + "%";
        ArrayList<HashMap> array_list = new ArrayList<HashMap>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from usuarios where " +
                "lower(nombre) like ? or lower(email) like ? or lower(cedula) like ? ", new String[]{filtro, filtro, filtro});
        res.moveToFirst();

        while (res.isAfterLast() == false) {
            //array_list.add(res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)));

            HashMap usuario = new HashMap();
            usuario.put("id", res.getInt(res.getColumnIndex("id")));
            usuario.put("nombre", res.getString(res.getColumnIndex("nombre")));
            usuario.put("cedula", res.getString(res.getColumnIndex("cedula")));
            usuario.put("email", res.getString(res.getColumnIndex("email")));

            array_list.add(usuario);

            res.moveToNext();
        }

        return array_list;
    }


    public ArrayList<HashMap> getAllUsuarios() {
        ArrayList<HashMap> array_list = new ArrayList<HashMap>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from usuarios ", null);
        res.moveToFirst();

        while (res.isAfterLast() == false) {
            //array_list.add(res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)));

            HashMap usuario = new HashMap();
            usuario.put("id", res.getInt(res.getColumnIndex("id")));
            usuario.put("nombre", res.getString(res.getColumnIndex("nombre")));
            usuario.put("cedula", res.getString(res.getColumnIndex("cedula")));
            usuario.put("email", res.getString(res.getColumnIndex("email")));
            usuario.put("contrasena", res.getString(res.getColumnIndex("contrasena")));

            array_list.add(usuario);

            res.moveToNext();
        }
        return array_list;
    }

    public HashMap findForLogin(String email, String password){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from usuarios where email = ? and contrasena = ?", new String[]{email, password});
        res.moveToFirst();
        HashMap usuario = null;
        while (res.isAfterLast() == false) {
            usuario = new HashMap();
            //array_list.add(res.getString(res.getColumnIndex(CONTACTS_COLUMN_NAME)));
            usuario.put("id", res.getInt(res.getColumnIndex("id")));
            usuario.put("nombre", res.getString(res.getColumnIndex("nombre")));
            usuario.put("cedula", res.getString(res.getColumnIndex("cedula")));
            usuario.put("email", res.getString(res.getColumnIndex("email")));


            res.moveToNext();
        }
        return usuario;
    }
}